<?php
require_once('config.php');
$output = '';
$output .= '
	<h3>Search Result</h3>
	<div class="table-responsive">
		<table class="table table-bordered table-striped">
			<tr>
				<th width="5%">No of tasks</th>
				<th width="61%">List Of Task\'s</th>
				<th width="10%">date</th>
				<th width="7%">From</th>
				<th width="7%">To</th>
				<th width="10%">Status</th>
			</tr>
		';
if(isset($_POST['date'])){
	$date = $_POST['date'];
	$sql = 'SELECT * FROM todo_list WHERE `date` LIKE "%'.$date.'%" ORDER BY todo_list.status DESC';
	$result = mysqli_query($db,$sql);
	$count = 0;
	if(mysqli_num_rows($result)>0){
		while($rows = mysqli_fetch_array($result)){
			$count++;
			if($rows['status'] == 0){
			$output .= '
				<tr>
					<td>'.$count.'</td>
					<td>'.$rows['todo'].'</td>
					<td>'.$rows['date'].'</td>
					<td>'.$rows['from'].'</td>
					<td>'.$rows['to'].'</td>
					<td class="text-danger">Uncomplete</td>
				</tr>
			';
			}
			else {
			$output .= '
				<tr>
					<td>'.$count.'</td>
					<td>'.$rows['todo'].'</td>
					<td>'.$rows['date'].'</td>
					<td>'.$rows['from'].'</td>
					<td>'.$rows['to'].'</td>
					<td class="text-success">Complete</td>
				</tr>
			';
			}
		}
	}
	else {
		$output .= '<tr>
			<td colspan="6">No Data Found</td>
		</tr>';
	}
	
}

$output .= '
		</table>
	</div>
';
echo $output;
?>