<?php

$db = mysqli_connect('localhost','root','','personal_record');
?>