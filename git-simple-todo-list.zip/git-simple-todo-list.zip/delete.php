<?php

require_once('config.php');


$id = $_POST['id'];

$sql = 'DELETE FROM todo_list WHERE id = '.$id.'';
if(mysqli_query($db,$sql)){
	echo "Data Deleted !";
}


?>