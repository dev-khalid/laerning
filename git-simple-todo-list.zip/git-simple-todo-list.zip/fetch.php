<?php

require_once('config.php');
$count = 1;
$output = '';
$output .= '
	<h3>Todo List</h3>
	<div class="table-responsive">
		<table class="table table-bordered table-striped">
			<tr>
				<th width="5%">No of tasks</th>
				<th width="61%">List Of Task\'s</th>
				<th width="10%">date</th>
				<th width="7%">From</th>
				<th width="7%">To</th>
				<th width="5%">Done</th>
				<th width="5%">Delete</th>
			</tr>
			<tr>
				<td>'.$count.'</td>
				<td id="todo_list" contenteditable></td>

				<td contenteditable id="add_date"></td>
				<td contenteditable id="add_from"></td>
				<td contenteditable id="add_to"></td>


				<td colspan="2" id="add_btn"><a><i class="fas fa-plus"></i></a></td>
			</tr>
		';
$sql = 'SELECT * FROM todo_list ORDER BY `id` DESC LIMIT 50';
$result = mysqli_query($db,$sql);


// if there is any task previously then it will fetch it 
if(mysqli_num_rows($result)>0){
	while($rows = mysqli_fetch_array($result)){


		$count++;

		if($rows['status']==1){

			$output .= '
				<tr class="success">
					<td>'.$count.'</td>
					<td contenteditable class="todo" data-id1="'.$rows['id'].'">'.$rows['todo'].'</td>

					<td contenteditable id="date" data-id4="'.$rows['id'].'" class="date">'.$rows['date'].'</td>
					<td contenteditable id="from" class="from" data-id5="'.$rows['id'].'">'.$rows['from'].'</td>
					<td contenteditable id="to" class="to" data-id6="'.$rows['id'].'">'.$rows['to'].'</td>


					<td class="edit" data-id2="'.$rows['id'].'"><a><i class="far fa-check-circle"></i></a></td>
					<td class="delete" data-id3="'.$rows['id'].'"><a><i class="far fa-times-circle"></i></a></td>
				</tr>
			';
		}

		else {

			$output .= '
				<tr>
					<td>'.$count.'</td>
					<td contenteditable class="todo" data-id1="'.$rows['id'].'">'.$rows['todo'].'</td>
					
					<td contenteditable id="date" data-id4="'.$rows['id'].'" class="date">'.$rows['date'].'</td>
					<td contenteditable id="from" class="from" data-id5="'.$rows['id'].'">'.$rows['from'].'</td>
					<td contenteditable id="to" class="to" data-id6="'.$rows['id'].'">'.$rows['to'].'</td>



					<td class="edit" data-id2="'.$rows['id'].'"><a><i class="far fa-check-circle"></i></a></td>
					<td class="delete" data-id3="'.$rows['id'].'"><a><i class="far fa-times-circle"></i></a></td>
				</tr>
			';
		}

	}
}



// otherwise it will fetch nothing
else{
	$output .= '
		<tr>
			<td colspan="7">No task found</td>
		</tr>
	';
}
$output .= '
		</table>
	</div>
';
echo $output;
?>


