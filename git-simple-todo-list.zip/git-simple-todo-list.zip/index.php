<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Time management System</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/all.css">
	<link rel="stylesheet" href="style.css">

	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/all.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="main.js"></script>
</head>
<body>
	<div class="container">
		<div class="average"></div>
		<div class="row search">
			<div class="col-md-6">
				<h4>Search Your Activity in todo List</h4>
			</div>
			<div class="col-md-6">
				<div class="form-group">
	                <div class='input-group'>
	                    <input type='text' class="form-control" id="date" placeholder="d/m/y"/>
	                    <span class="input-group-addon">
	                        <span class="glyphicon glyphicon-search"></span>
	                    </span>
	                </div>
	            </div>
	        </div>
		</div>
		<div id="search_result"></div>
		<div id="live_data"></div>
	</div>
</body>
</html>