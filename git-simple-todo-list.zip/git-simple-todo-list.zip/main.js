jQuery(document).ready(function(){
//making the average todo_list completation rate
	function avg(){
		$.ajax({
			url: 'average.php',
			method: 'POST',
			success:function(data){
				jQuery('.average').html(data);
			}
		});
	}

//fetching data from the database
	function fetch_todo(){
		$.ajax({
			url: 'fetch.php',
			method: 'POST',
			success:function(data){
				jQuery('#live_data').html(data);
			}
		});
	}
	fetch_todo();
	avg();

//insert data into the database 
	function insert_data(todo,date,from,to){
		$.ajax({
			url: 'insert.php',
			method: 'POST',
			data: {
				todo_list: todo,
				date: date,
				from: from,
				to: to
			},
			dataType: 'text',
			success: function(data){
				fetch_todo();
				avg();
			}
		});
	}

	jQuery(document).on('click','#add_btn', function(){
		var todo = $('#todo_list').text();
		var date = $('#add_date').text();
		var from = $('#add_from').text();
		var to = $('#add_to').text();

		$.trim(todo);
		$.trim(date);
		$.trim(from);
		$.trim(to);
		if(todo == ''){
			alert('Please Insert A valid Task!');
			return false;
		}
		else {
			insert_data(todo,date,from,to);
		}
	});

//function that edit or update the data 
	function edit_todo(id,text){

		$.ajax({
			url:'update.php',
			method: 'POST',
			data: {
				id:id,
				text:text
			},
			dataType: 'text',
			success:function(data){
				fetch_todo();
				avg();
			}

		});
	}
	$(document).on('blur','.todo',function(){
		var id = $(this).data("id1");
		var text = $(this).text();
		edit_todo(id,$.trim(text));
	})

// Function to edit date 
	function edit_date(id,date){
		$.ajax({
			url: 'update.php',
			method: 'POST',
			data: {
				id:id,
				date:date
			},
			dataType:'text',
			success: function(data){
				fetch_todo();
				avg();
			}
		});
	}
	jQuery(document).on('blur','.date',function(){
		var id = $(this).data('id4');
		var date = $(this).text();
		edit_date(id,date);
	})

//function to edit Starting time
	function edit_from(id,from){
		$.ajax({
			url: 'update.php',
			method: 'POST',
			data: {
				id:id,
				from: from
			},
			dataType: 'text',
			success:function(data){
				fetch_todo();
				avg();
			}
		});
	}
	
	jQuery(document).on('blur','.from',function(){
		var id = $(this).data('id5');
		var from = $(this).text();
		edit_from(id,from);
	})

//function to edit ending time
	function edit_to(id,to){
		$.ajax({
			url: 'update.php',
			method: 'POST',
			data: {
				id:id,
				to:to
			},
			dataType: 'text',
			success: function(data){
				fetch_todo();
				avg();
			}
		});
	}

	jQuery(document).on('blur','.to',function(){
		var id = $(this).data('id6');
		var to = $(this).text();

		edit_to(id,to);
	})

//function for deleting data 
	function delete_data(id){
		if(confirm("Are you sure want to delete This?")){
			$.ajax({
				url: 'delete.php',
				method: 'POST',
				data: {id:id},
				dataType: 'text',
				success:function(data){
					fetch_todo();
					avg();
				}
			});
		}
	}

//executing the function 
	$(document).on('click','.delete',function(){
		var id = $(this).data('id3');
		delete_data(id);
	})

//line-through functionality 
	function update_status(id){
		if(confirm("Have You Finished The task?")){
			$.ajax({
				url: 'update_status.php',
				method: 'POST',
				data: {id:id},
				success:function(data){
					fetch_todo();
					avg();
				}
			});
		}
	}
	$(document).on('click','.edit',function(){
		var id = $(this).data("id2");
		update_status(id);
	});

	//------------Search By Date---------
	$('#date').on('keyup',function(){
		var date = $(this).val();
		if(date != ''){
			$.ajax({
				url: 'search.php',
				method: 'POST',
				data: {
					date:date
				},
				success:function(data){
					jQuery('#search_result').html(data);
				}
			});
		}
		else {
			jQuery('#search_result').html('');
		}
	});
});

