<?php

require_once('config.php');
//counting uncomplete works
$q1 = 'SELECT * FROM todo_list WHERE todo_list.status = "0"';
$r1 = mysqli_query($db,$q1);
$uncomplete = mysqli_num_rows($r1);

//counting completed works
$q2 = 'SELECT * FROM todo_list WHERE todo_list.status = "1"';
$r2 = mysqli_query($db,$q2);
$complete = mysqli_num_rows($r2);

//counting total works
$sql = 'SELECT * FROM todo_list';
$result = mysqli_query($db,$sql);
$total = mysqli_num_rows($result);

$output = '';

$c_r = $complete/$total*100; //$c_r => completation rate
$unc_r = $uncomplete/$total*100;

$output .= '
	<div class="row">
	<div class="col-md-6" >
		<h4 class="text-success">Task Complete Rate : '.$c_r.'%('.$complete.')</h4>
	</div>
	<div class="col-md-6">
		<h4 class="text-danger" style="float: right">Task Uncomplete Rate : '.$unc_r.'%('.$uncomplete.')</h4>
	</div>
	</div>
';
echo $output;


?>