<?php
require_once('config.php');

if(isset($_POST['text'])){


	$id = $_POST['id'];
	$text = $_POST['text'];

	$sql = 'UPDATE todo_list SET todo="'.$text.'" WHERE id = '.$id.'';

	if(mysqli_query($db,$sql)){
		echo "Todo List Updated Successfully!";
	}
}

if(isset($_POST['date'])){


	$id = $_POST['id'];
	$date = $_POST['date'];

	$sql = 'UPDATE todo_list SET todo_list.date ="'.$date.'" WHERE id = '.$id.'';

	if(mysqli_query($db,$sql)){
		echo "Date Updated Successfully!";
	}
}
if(isset($_POST['from'])){


	$id = $_POST['id'];
	$from = $_POST['from'];

	$sql = 'UPDATE todo_list SET todo_list.from="'.$from.'" WHERE id = '.$id.'';

	if(mysqli_query($db,$sql)){
		echo "Starting time Updated Successfully!";
	}
}
if(isset($_POST['to'])){


	$id = $_POST['id'];
	$to = $_POST['to'];

	$sql = 'UPDATE todo_list SET todo_list.to="'.$to.'" WHERE id = '.$id.'';

	if(mysqli_query($db,$sql)){
		echo "Ending time Updated Successfully!";
	}
}
?>