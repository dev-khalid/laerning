<?php

require_once('config.php');


$id = $_POST['id'];

$sql = 'UPDATE todo_list SET status = 1 WHERE id = '.$id.'';
if(mysqli_query($db,$sql)){
	echo "Congratulations!";
}

?>