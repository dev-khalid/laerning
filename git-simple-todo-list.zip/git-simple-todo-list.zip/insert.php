<?php
require_once('config.php');


$todo_list = $_POST['todo_list'];
$from = $_POST['from'];
$to = $_POST['to'];
$date = $_POST['date'];


$output = '';
$sql = 'INSERT INTO todo_list(`todo`,`from`,`to`,`date`) values("'.$todo_list.'","'.$from.'","'.$to.'","'.$date.'")';
if(mysqli_query($db,$sql)){
	$output .= "Data Inserted Successfully!";
}
echo $output;
?>