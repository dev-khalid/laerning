<?php
$connect = mysqli_connect("localhost","root","","localproject");
if($connect->connect_error){
	die('Connection Error:'.$connect->connect_error);
}
?>