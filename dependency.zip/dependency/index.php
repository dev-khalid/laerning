<?php

require_once('config.php');
$query = "SELECT * FROM countries WHERE status = 1 ORDER BY country_name ASC";
$result = mysqli_query($connect,$query);
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Load more data using jQuery Ajax PHP MySql</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="script.js"></script>
</head>
<body>


	<div class="container-fluid">
		<h3>Dependent Dropdown list</h3>
		<div class="row">


			<!-- the following div is for selecting country dynamically -->
			<div class="col-md-4">
				<div class="form-group">
					<label for="country">Select Country</label>
					<select id="country" class="form-control">
						<option value="">Select Country</option>
						<?php

							if(mysqli_num_rows($result)>0){
								while($rows = mysqli_fetch_array($result)){
									echo '<option value="'.$rows['country_id'].'">'.$rows['country_name'].'</option>';
								}
							}
							else {
								echo '<option value="">No Country Found</option>';
							}

						?>
					</select>
				</div>
			</div>


			<!-- the following div is used to fetch states  -->
			<div class="col-md-4">
				<div class="form-group">
					<label for="state">Select State</label>
					<select id="state" class="form-control">
						<option value="">Select Country First</option>
					</select>
				</div>
				
			</div>

			<!-- the following div is to fetch cities -->
			<div class="col-md-4">
				<div classs="form-group">
					<label for="city">Select City</label>
					<select id="city" class="form-control">
						<option value="">Select State First</option>
					</select>
				</div>
			</div>
		</div>
	</div>
</body>
</html>