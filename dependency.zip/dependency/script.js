jQuery(document).ready(function(){

	// onchange country this function will fetch state name
	jQuery('#country').on('change',function(){
		var countryId = $(this).val();


		$.ajax({
			url: 'fetch.php',
			method: 'POST',
			data: {
				'country_id': countryId
			},
			success:function(data){
				$('#state').html(data);
			}
		});
	});


	// onchange state the following function will fetch country name
	jQuery('#state').on('change',function(){
		var stateId = $(this).val();


		$.ajax({
			url: 'fetch.php',
			method: 'POST',
			data: {
				'state_id': stateId
			},
			success:function(result){
				$('#city').html(result);
			}
		});
	});
});