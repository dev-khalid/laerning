<?php 
	require_once('connection.php');

	// inserting data 
	if(isset($_POST['add_btn']))
	{
		$insertSql = "CALL insertCountry('".$_POST["country_name"]."')";
		if(mysqli_query($connection,$insertSql))
		{
			header('location: index.php?inserted=1');
		}
	}
	//end of inserting data
	// updating data
	if(isset($_POST['edit_btn']))
	{
		$updateSql = "CALL updateCountry('".$_POST['country_id']."','".$_POST['country_name']."')";
		$updateResult = mysqli_query($connection,$updateSql);
		if($updateResult)
		{
			header('location: index.php?updated=1');
		}
	}
	// update ends here

	// Deleting data
	if(isset($_GET['delete']))
	{
		$deleteSql = "CALL deleteCountry('".$_GET['country_id']."')";
		if(mysqli_query($connection,$deleteSql))
		{
			header("location: index.php?deleted=1");
		}
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Insert Read Update Delete</title>
	<script src="js/jquery-3.3.1.min.js"></script>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="js/bootstrap.min.js">
	<link rel="stylesheet" href="style.css">
	<script src="scripts.js"></script>
</head>
<body>
	<div class="box container">
		<h3 style="text-align: center"><a class="btn btn-info" href="index.php">Home</a></h3>
		<!-- editing data -->
		<?php
			if(isset($_GET['edit']))
			{
				$singleSql = "CALL singleCountry('".$_GET['country_id']."')";
				$singleResult = mysqli_query($connection,$singleSql);
				if(mysqli_num_rows($singleResult)>0)
				{
					while($singleRows = mysqli_fetch_array($singleResult))
					{
		?>
			<form action="" method="POST" name="edit_country">
				<h2>Edit Country</h2>
				<div class="form-group">
					<label for="country_name">Edit your country name:</label>
					<input type="text" name="country_name" class="form-control" id="country_name" value="<?php echo $singleRows['country_name'];?>">
				</div>
				<input type="hidden" name="country_id" value="<?php echo $singleRows["country_id"];?>">
				<input type="submit" value="Edit Country" name="edit_btn" class="btn btn-info">
			</form>
		<?php 		
					}
					mysqli_next_result($connection);
				}
			}
		// editing ends here
			else
			{
		?>
			<form action="" method="POST" name="add_country">
				<h2>Add Country</h2>
				<div class="form-group">
					<label for="country_name">Enter your country name:</label>
					<input type="text" name="country_name" class="form-control" id="country_name">
				</div>
				<input type="submit" value="Add Country" name="add_btn" class="btn btn-info">
			</form>
		<?php
			}
		?>
		

		<div class="table-responsive">
			<table class="table table-striped table-bordered">
				<tr>
					<th>Country Name</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
				
				<?php 
					$selectSql = "CALL selectCountry()";
					$selectResult = mysqli_query($connection,$selectSql);
					if(mysqli_num_rows($selectResult) > 0)
					{
						while($selectRows = mysqli_fetch_array($selectResult))
						{
				?>
					<tr>
						<td><?php echo $selectRows['country_name'];?></td>
						<td><a href="index.php?edit=1&country_id=<?php echo $selectRows['country_id'];?>">Edit</a></td>
						<td><a href="index.php?delete=1&country_id=<?php echo $selectRows['country_id'];?>" onclick="return confirm('Are you sure want to delete this?');" class="delete_btn">Delete</a></td>
					</tr>
				<?php		
						}	
						mysqli_next_result($connection);					
					}
					else
					{
				?>
					<tr>
						<td colspan="3">No Data Found</td>
					</tr>
				<?php
					}
				?>
			</table>
		</div>
	</div>
</body>
</html>