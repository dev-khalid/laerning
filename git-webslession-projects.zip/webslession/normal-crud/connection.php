<?php
	// creating connection with the database
	$connection = mysqli_connect('localhost','root','','webslession');
?>