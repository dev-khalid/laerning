jQuery(document).ready(function(){
	jQuery('#btn_delete').click(function(){
		
		if(confirm("Are you sure want to delete this?"))
		{
			var id = [];
			jQuery('input[type="checkbox"]:checked').each(function(i){
				id[i] = jQuery(this).val();
			});
			if(id.length === 0)
			{
				alert('Please select at least one to delete');
			}
			else 
			{
				$.ajax({
					url: 'delete.php',
					method: 'POST',
					data: {id:id},
					success: function(){
						for(var i=0;i<id.length;i++)
						{
							jQuery('button#'+id[i]+'').css('background','#ccc');
							jQuery('button#'+id[i]+'').fadeOut('slow');
						}
					}
				});
			}
		}
		else 
		{
			return false;
		}
	});
});