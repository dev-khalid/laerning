<?php
require_once('config.php');
$sql = "SELECT * FROM tbl_live";
$result = mysqli_query($connect,$sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Load more data using jQuery Ajax PHP MySql</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="scripts.js"></script>
</head>
<body>
	<div class="contianer">
		<h3>Delete multiple value using Ajax PHP MySql jQuery</h3>
		<?php
			if(mysqli_num_rows($result)>0)
			{
		?>
		<div class="table-responsive">
			<table class="table table-bordered">
				<tr>
					<th>Id</th>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Delete</th>
				</tr>
		<?php
				while($rows = mysqli_fetch_array($result))
				{
		?>
				<tr id='<?php echo $rows["id"];?>'>
					<td><?php echo $rows['id'];?></td>
					<td><?php echo $rows['first_name'];?></td>
					<td><?php echo $rows['last_name'];?></td>
					<td><input type="checkbox" name="id[]" class="delete_id" id="<?php echo $rows['id'];?>" value="<?php echo $rows['id'];?>"/></td>
				</tr>
		<?php
				}
		?>

			</table>
		</div>
		<?php
			}
		?>
		<div class="delete">
			<button class="btn btn-danger" id="btn_delete">Delete</button>
		</div>
	</div>
</body>
</html>