<?php
require_once('config.php');
	if(isset($_GET['delete']))
	{	
		$tweet_id = $_GET['tweet_id'];
		$deleteSql = "DELETE FROM tbl_tweet WHERE tweet_id = '".$tweet_id."' ";
		mysqli_query($connection,$deleteSql);
	}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Ajax auto Refresh div content</title>
	<script src="js/jquery-3.3.1.min.js"></script>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="js/bootstrap.min.js">
	<link rel="stylesheet" href="style.css">
	<script src="scripts.js"></script>
</head>
<body>
	<div class="box">
		<div class="container-fulid content">
			<form action="" method="POST">
				<div class="form-group">
					<label for="tweet">Tweet Here</label>
					<textarea name="tweet" id="tweet" class="form-control"></textarea>
				</div>
				<input type="submit" value="Tweet" class="btn btn-info" id="send" >
			</form>
			<div class="load_tweet"></div>
		</div>
	</div>
</body>
</html>
