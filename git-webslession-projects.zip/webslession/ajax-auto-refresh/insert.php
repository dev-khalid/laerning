<?php
require_once('config.php');
$insertSql = "INSERT INTO tbl_tweet(tweet) VALUES ('".$_POST['tweet_txt']."')";
mysqli_query($connection,$insertSql);
?>