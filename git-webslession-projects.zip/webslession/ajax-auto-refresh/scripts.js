jQuery(document).ready(function(){
	jQuery('#send').click(function(){
		var tweet = jQuery('#tweet').val();
		if($.trim(tweet) != '')
		{
			$.ajax({
				url: 'insert.php',
				method: 'POST',
				data : {
					tweet_txt : tweet
				},
				dataType: "text",
				success: function(result){
					jQuery('#tweet').val('');
				}
			});
		}
		return false;
	});
	setInterval(function(){
		jQuery('.load_tweet').load('fetch.php').fadeIn("slow");
	},1000);
});