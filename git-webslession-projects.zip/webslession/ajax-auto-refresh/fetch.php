<?php
require_once('config.php');
	$selectSql = "SELECT * FROM tbl_tweet ORDER BY tweet_id DESC";
	$selectResult = mysqli_query($connection,$selectSql);
	if(mysqli_num_rows($selectResult)>0)
	{
		while($rows = mysqli_fetch_array($selectResult)){
?>
			<p><?php echo $rows['tweet'];?><a class="btn btn-danger" onclick="return confirm('Are you sure  want to delete this tweet');" href="index.php?delete=1&tweet_id=<?php echo $rows['tweet_id'];?>">Delete</a></p>
<?php
		}
	}
	else {
		echo "<p>No Tweet Found</p>";
	}
?>
