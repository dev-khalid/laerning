jQuery(document).ready(function(){
	jQuery(document).on('click','#btn_more',function(){
		var last_id = jQuery(this).data('last-id');
		jQuery('#btn_more').html('Loading...');
		$.ajax({
			url: 'load_data.php',
			method: 'POST',
			data: {
				last_id : last_id
			},
			dataType: 'text',
			success: function(data){
				if(data != '')
				{
					jQuery('#remove_row').remove();
					jQuery('#load_data_table').append(data);
				}
				else  
				{
					jQuery('#btn_more').html('No Data');
				}
			}
		});
	});
});