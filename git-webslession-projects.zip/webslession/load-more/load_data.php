<?php
require_once('config.php');
$output = '';
$last_id = '';
$sql = "SELECT * FROM tbl_live WHERE id > ".$_POST['last_id']." LIMIT 2";
$result = mysqli_query($connect,$sql);
if(mysqli_num_rows($result)>0)
{
	while($rows = mysqli_fetch_array($result))
	{
		$last_id = $rows['id'];
		$output .= '
			<tbody><tr>
				<td>'.$rows['id'].'</td>
				<td>'.$rows['first_name'].'</td>
				<td>'.$rows['last_name'].'</td>
			</tr></tbody>
		';
	}
	$output .= '
			<tbody>
				<tr id="remove_row">
					<td colspan="3"><button class="btn btn-info form-control" type="button" data-last-id="'.$last_id.'" id="btn_more">Load More</button></td>
				</tr>
			</tbody>
	';
	echo $output;
}