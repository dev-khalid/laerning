<?php
require_once('config.php');
$sql = "SELECT * FROM tbl_live LIMIT 2";
$result = mysqli_query($connect,$sql);
$last_id = '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Load more data using jQuery Ajax PHP MySql</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="scripts.js"></script>
</head>
<body>
	<div class="table-container table-responsive">
		<h3>Load more data using jQuery Ajax PHP MySql</h3>
		<table class='table table-bordered' id="load_data_table">
			
			<tr>
				<th>Id</th>
				<th>First Name</th>
				<th>Last Name</th>
			</tr>
		<?php
			while($rows = mysqli_fetch_array($result)){
		?>
			<tr>
				<td><?php echo $rows['id'];?></td>
				<td><?php echo $rows['first_name'];?></td>
				<td><?php echo $rows['last_name'];?></td>
			</tr>
		<?php
			$last_id = $rows['id'];
			}
		?>
			<tr id="remove_row">
				<td colspan="3">
					<button name="btn_more" class="btn btn-info form-control" id="btn_more" data-last-id="<?php echo $last_id;?>">Load More</button>
				</td>
			</tr>
		</table>
	</div>
</body>
</html>