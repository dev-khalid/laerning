<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Load more data using jQuery Ajax PHP MySql</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/all.css">
	<link rel="stylesheet" href="style.css">
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/all.js"></script>
	<script src="scripts.js"></script>
</head>
<body>
	<div class="container">
		<form method="POST">
			<div class="form-group has-feedback">
				<label for="password">Enter your password</label>
				<input type="password" class="form-control" name="password" id="password" placeholder="password">
				<span id="view" class="far fa-eye form-control-feedback"></span>
			</div>
		</form>
	</div>
</body>
</html>