jQuery(document).ready(function(){
	jQuery('#view').on('click',function(){
		var passwordField = jQuery('#password');
		var passwordFieldType = jQuery('#password').attr('type');
		if(passwordFieldType == 'password')
		{
			passwordField.attr('type','text');
		}
		else
		{
			passwordField.attr('type','password');
		}
	});
});