<?php

require_once('config.php');

if(isset($_POST['country_id'])){
    $output = '<option value="">Select State</option>';
    $query = 'SELECT * FROM states WHERE country_id = '.$_POST['country_id'].' AND status = 1 ORDER BY state_name ASC';
    $result = mysqli_query($connect,$query);
    if(mysqli_num_rows($result)>0){
        while($rows = mysqli_fetch_array($result)){
            $output .= '<option value="'.$rows['state_id'].'">'.$rows['state_name'].'</option>';
        }
    }

    echo $output;
}
if(isset($_POST['state_id'])){
    $output = '<option value="">Select District</option>';
    $query = 'SELECT * FROM district WHERE state_id = '.$_POST['state_id'].' AND status = 1 ORDER BY district_name ASC';
    $result = mysqli_query($connect,$query);
    if(mysqli_num_rows($result)>0){
        while($rows = mysqli_fetch_array($result)){
            $output .= '<option value="'.$rows['district_id'].'">'.$rows['district_name'].'</option>';
        }
    }
    echo $output;
}
if(isset($_POST['district_id'])){
    $output = '<option value="">Select City</option>';
    $query = 'SELECT * FROM cities WHERE district_id = '.$_POST['district_id'].' AND status = 1 ORDER BY city_name ASC';
    $result = mysqli_query($connect,$query);
    if(mysqli_num_rows($result)>0){
        while($rows = mysqli_fetch_array($result)){
            $output .= '<option value="'.$rows['city_id'].'">'.$rows['city_name'].'</option>';
        }
    }
    echo $output;
}
?>