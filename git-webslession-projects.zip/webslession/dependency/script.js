jQuery(document).ready(function(){

function dependency(){

	// onchange country this function will fetch state name
	jQuery('#country').on('change',function(){
		var countryId = $(this).val();
		$.ajax({
			url: 'fetch.php',
			method: 'POST',
			data: {
				'country_id': countryId
			},
			success:function(data){
				$('#state').html(data);
			}
		});
	});


	// onchange state the following function will fetch district name
	jQuery('#state').on('change',function(){
		var stateId = $(this).val();


		$.ajax({
			url: 'fetch.php',
			method: 'POST',
			data: {
				'state_id': stateId
			},
			success:function(result){
				$('#district').html(result);
			}
		});
	});

	//onchange district the following code will fetch 
	jQuery('#district').on('change',function(){
		var districtId = $(this).val();

		$.ajax({
			url: 'fetch.php',
			method: 'POST',
			data :{'district_id':districtId},
			success:function(data){
				jQuery('#city').html(data);
			}
		});
	});
}
dependency();


	function insert(){
	//--------Inserting Data to the Database-------
		jQuery('button').click(function(){
			// fetching text's from the selected option to add it on the database;
			var country = document.getElementById('country');
			country_text = country.options[country.selectedIndex].text;

			var state = document.getElementById('state');
			state_text = state.options[state.selectedIndex].text;

			var district = document.getElementById('district');
			district_text = district.options[district.selectedIndex].text;
			district_value = district.options[district.selectedIndex].value;
			if(district_value == ''){
				district_text = 'Not Selected';
			}
			var city = document.getElementById('city');
			city_text = city.options[city.selectedIndex].text;
			city_value = city.options[city.selectedIndex].value;
			if(city_value == '') {
				city_text = 'Not Selected';
			}
			if(country_text != '' && state_text != ''){
				$.ajax({
					url: 'insert.php',
					method: 'POST',
					data: {
						'country' : country_text,
						'state'   : state_text,
						'district': district_text,
						'city'    : city_text
					},
					success:function(data){
						alert(data);
					}
				});
			}
		});
	}
	insert();
	
});