<?php
require_once('config.php');

$country = $_POST['country'];
$state = $_POST['state'];
$district = $_POST['district'];
$city = $_POST['city'];

$sql = 'INSERT INTO data(`country`,`state`,`district`,`city`) VALUES("'.$country.'","'.$state.'","'.$district.'","'.$city.'")';
if(mysqli_query($connect,$sql)){
	echo 'Data Inserted Successfully!';
}
?>