jQuery(document).ready(function(){
	function fetch_data(){
		$.ajax({
			url: 'fetch.php',
			method: 'POST',
			success: function(result){
				jQuery('#live_table').html(result);
			}
		});
	}
	fetch_data();
	// insert data
	jQuery(document).on('click','#btn_add',function(){
		var first_name = jQuery('#first-name').text();
		var last_name = jQuery('#last-name').text();
		if(first_name == '')
		{
			alert("Enter First name");
			return false;
		}
		if(last_name == '')
		{
			alert("Enter Last name");
			return false;
		}
		$.ajax({
			url: 'insert.php',
			method: 'POST',
			data: {
				first_name : first_name,
				last_name : last_name
			},
			dataType: 'text',
			success : function(data){
				alert(data);
				fetch_data();
			}
		});
	}); // end of inserting data section 
	// edit process
	function edit_data(id,text,column_name){
		$.ajax({
			url: 'edit.php',
			method: 'POST',
			data: {
				id: id,
				text: text,
				column_name: column_name
			},
			success: function(){
				fetch_data();
			}
		});
	}
	jQuery(document).on('blur','.first-name',function(){
		var id = jQuery(this).data("id1");
		var first_name = jQuery(this).text();
		edit_data(id,first_name,"first_name");
	});
	jQuery(document).on('blur','.last-name',function(){
		var id = jQuery(this).data("id2");
		var last_name = jQuery(this).text();
		edit_data(id,last_name,"last_name");
	});
	// end of updating data 

	// delete data 
	jQuery(document).on('click',"#btn_delete",function(){
		$.ajax({
			url: 'delete.php',
			method: 'POST',
			data: {
				id: jQuery(this).data('id3')
			},
			success: function(){
				fetch_data();
			}
		});
	});
	jQuery('#search').keyup(function(){
		var txt = jQuery(this).val();
		if(txt != '')
		{
			$.ajax({
				url: 'search.php',
				method: 'POST',
				data: {
					txt: txt
				},
				dataType: 'text',
				success: function(data){
					jQuery('.search_result').html(data);
				}
			});
		}
		else {
			jQuery('.search_result').html('');
		}
	});
});