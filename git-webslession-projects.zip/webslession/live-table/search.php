<?php
require_once('config.php');
$searchSql = "SELECT * FROM tbl_live WHERE first_name LIKE '%".$_POST['txt']."%' OR last_name LIKE '%".$_POST['txt']."%' OR id LIKE '%".$_POST['txt']."%'";
$searchResult = mysqli_query($connection,$searchSql);
?>

	<div class='table-responsive'>
		<table class='table table-bordered'>
			<tr>
				<th>Id</th>
				<th>First Name</th>
				<th>Last Name</th>
			</tr>
<?php
if(mysqli_num_rows($searchResult)>0)
{
	while($rows = mysqli_fetch_array($searchResult)){
?>
			<tr>
				<td><?php echo $rows['id'];?></td>
				<td><?php echo $rows['first_name'];?></td>
				<td><?php echo $rows['last_name'];?></td>
			</tr>

<?php
	}
}
else {
?>
			<tr>
				<td colspan="3">No data Found</td>
			</tr>
<?php
}
?>
		</table>
	</div>