<?php
require_once('config.php');
$deleteSql = "DELETE FROM tbl_live WHERE id = '".$_POST['id']."'";
mysqli_query($connection,$deleteSql);
?>