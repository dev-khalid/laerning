<?php
require_once('config.php');
$insertSql = "INSERT INTO tbl_live(first_name,last_name) VALUES ('".$_POST['first_name']."','".$_POST['last_name']."')";
if(mysqli_query($connection,$insertSql))
{
	echo "Data Inserted Successfully";
}
?>
