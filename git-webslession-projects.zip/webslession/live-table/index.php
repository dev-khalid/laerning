<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Live Table|Insert|Update|Delete</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="scripts.js"></script>
	<script src="js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container box">
		<div class="search-box">
			<h3>Ajax Live data search using php mysql ajax</h3>
			<div class="form-group">
				<div class="input-group">
					<span class="input-group-addon">Search</span>
					<input type="text" name="search" class="form-control" id="search" placeholder="Search By First Name or Last Name Or by Id">
				</div>
			</div>
			<div class="search_result"></div>
		</div>
		<h3>Live Table | Create | Edit | Update | Delete</h3>
		<div id="live_table"></div>
		<form action="excel.php" name="excel">
			<input type="submit" class="btn btn-info" value="Download Excel File">
		</form>
	</div>
</body>
</html>