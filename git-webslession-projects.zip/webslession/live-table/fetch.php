<?php
require_once('config.php');
$selectSql = "SELECT * FROM tbl_live ORDER BY id ASC";
$selectResult = mysqli_query($connection , $selectSql);
?>
	<div class="table-responsive">
		<table class="table table-striped table-bordered">
			<tr>
				<th width="10%">Id</th>
				<th width="40%">First Name</th>
				<th width="40%">Last Name</th>
				<th width="10%">Action</th>
			</tr>
<?php
if(mysqli_num_rows($selectResult)>0){
	while($rows = mysqli_fetch_array($selectResult))
	{
?>
			<tr>
				<td><?php echo $rows["id"];?></td>
				<td contenteditable="true" class="first-name" data-id1="<?php echo $rows['id'];?>"><?php echo $rows["first_name"];?></td>
				<td contenteditable="true" class="last-name" data-id2="<?php echo $rows['id'];?>"><?php echo $rows["last_name"];?></td>
				<td><button class="btn btn-xs btn-danger" onclick="return confirm('Are you sure want to Delete This')" id="btn_delete" data-id3="<?php echo $rows['id'];?>">X</button></td>
			</tr>
<?php
	}
}
else {
?>
			<tr>
				<td colspan="4">No Data Found</td>
			</tr>

<?php
}
?>			
			<tr>
				<td></td>
				<td contenteditable="true" id="first-name"></td>
				<td contenteditable="true" id="last-name"></td>
				<td><button class="btn btn-xs btn-success" id="btn_add">+</button></td>
			</tr>
		</table>
	</div>