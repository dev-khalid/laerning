<?php
require_once('config.php');
$column_name = $_POST['column_name'];
$updateSql = "UPDATE tbl_live SET $column_name = '".$_POST['text']."' WHERE id = '".$_POST['id']."'";
mysqli_query($connection,$updateSql);
?>