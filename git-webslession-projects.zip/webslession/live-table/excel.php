<?php
require_once('config.php');
$selectSql = "SELECT * FROM tbl_live";
$selectResult = mysqli_query($connection,$selectSql);
$output = '';
if(mysqli_query($connection,$selectSql))
{
	if(mysqli_num_rows($selectResult)>0)
	{
		$output .= '
				<table class="table" bordered="1">
					<tr>
						<th>Id</td>
						<th>First Name</th>
						<th>Last Name</th>
					</tr>
		';
		while($rows = mysqli_fetch_array($selectResult))
		{
			$output .= '
					<tr>
						<td>'.$rows['id'].'</td>
						<td>'.$rows['first_name'].'</td>
						<td>'.$rows['last_name'].'</td>
					</tr>
			';

		}
		$output .= "</table>";
		header('Content-Type: application/xls');
		header('Content-Disposition: attachment; filename= Download.xls ');
		echo $output;
	}
}
