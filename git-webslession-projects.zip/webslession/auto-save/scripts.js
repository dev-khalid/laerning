jQuery(document).ready(function(){
	function autoSave(){
		var post_id = jQuery('#post_id').val();
		var post_title = jQuery('#post_title').val();
		var post_description = jQuery('#post_description').val();
		if(post_title != '' && post_description != '')
		{
			$.ajax({
				url: 'save_post.php',
				method: 'POST',
				data: {
					postTitle: post_title,
					postDescription : post_description,
					postId: post_id
				},
				dataType: 'text',
				success: function(data){
					if(data != '')
					{
						jQuery('#post_id').val(data);
					}
					jQuery('#autoSave').text('Post Saved As Draft');
					setInterval(function(){
						jQuery('#autoSave').text('');
					},3000);
				}
			});
		}
	}
	setInterval(function(){
		autoSave();
	},10000);
});