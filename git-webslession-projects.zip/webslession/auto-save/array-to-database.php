<?php
$connect = mysqli_connect('localhost','root','','webslession');
$live_table = array(
	"0" => array('21','Robin',"Ahmed"),
	"1" => array('22','Khalid',"Hossain"),
	"2" => array('23','Engineer','Khalid')
);
function insert_into_db($array,$connect){
	if(is_array($array))
	{
		foreach($array as $key => $value){
			$id = $value[0];
			$first_name = $value[1];
			$last_name = $value[2];
			$sql = "INSERT INTO tbl_live(id,first_name,last_name) VALUES ('".$id."','".$first_name."','".$last_name."')";
			mysqli_query($connect,$sql);
		}
	}
	
}
insert_into_db($live_table,$connect);
?>