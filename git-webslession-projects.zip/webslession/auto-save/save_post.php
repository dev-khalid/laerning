<?php
require_once('config.php');
$post_id = $_POST['postId'];
if($_POST['postId'] != '')
{	
	// update data
	$updateSql = "UPDATE tbl_post SET post_title='".$_POST['postTitle']."',post_description='".$_POST['postDescription']."' WHERE post_id = '".$_POST['postId']."'";
	mysqli_query($connect,$updateSql);
}
else 
{
	// insert data
	$insertSql = "INSERT INTO tbl_post(post_title,post_description,post_status) VALUES('".$_POST['postTitle']."','".$_POST['postDescription']."','draft')";
	mysqli_query($connect,$insertSql);
	echo mysqli_insert_id($connect);
}