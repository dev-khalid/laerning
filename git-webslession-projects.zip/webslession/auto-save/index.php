<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Load more data using jQuery Ajax PHP MySql</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="scripts.js"></script>
</head>
<body>
	<div class="contianer box">
		<h3>Auto Save Post using ajax PHP MySql jQuery</h3>
		<div class="form-group">
			<label for="post_title">Post Title</label>
			<input type="text" name="post_title" class="form-control" id="post_title">
		</div>
		<div class="form-group">
			<label for="post_description">Post Description</label>
			<textarea name="post_description" rows="9" class="form-control" id="post_description"></textarea>
		</div>
		<div class="form-group">
			<input type="hidden" name="post_id" class="form-control" id="post_id">
			<div id='autoSave'></div>
		</div>
	</div>
</body>
</html>