<?php
require_once('config.php');
$selectSql = "SELECT * FROM tbl_user WHERE user_name = '".$_POST["user_name"]."'";
$selectResult = mysqli_query($connection,$selectSql);
if(mysqli_num_rows($selectResult)>0){
	echo "<p class='danger'>User Name Unavailable!</p>";
}
else {
	echo "<p class='success'>User Name Available!</p>";
}
?>