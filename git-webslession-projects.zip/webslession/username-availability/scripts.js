jQuery(document).ready(function(){
	jQuery('#username').blur(function(){
		$.ajax({
			url: 'check.php',
			method: 'POST',
			data: {
				user_name: jQuery(this).val()
			},
			dataType: 'text',
			success: function(result){
				jQuery('.availability').html(result);
			}
		});
	});
});