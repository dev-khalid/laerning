<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Username Availability</title>
	<script src="js/jquery-3.3.1.min.js"></script>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
	<script src="scripts.js"></script>
</head>
<body>
	<div class="box">
		<div class="container-fluid">
			<form action="" method="POST">
				<div class="form-group">
					<label for="username">Enter Username:</label>
					<input type="text" name="username" id="username" class="form-control">
					<div class="availability"></div>
				</div>
			</form>
		</div>
	</div>
</body>
</html>