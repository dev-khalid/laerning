<?php
require_once('config.php');
if(isset($_POST['view']))
{
	if($_POST['view'] != '')
	{
		$update = 'UPDATE comments SET comment_status = 1 WHERE comment_status = 0';
		mysqli_query($connect,$update);
	}
	$query = 'SELECT * FROM comments ORDER BY comment_id DESC LIMIT 5';
	$result = mysqli_query($connect,$query);
	$output = '';
	if(mysqli_num_rows($result)>0){
		while($rows = mysqli_fetch_array($result))
		{
			$output .= '
				<li>
					<a href="#">
						<strong>'.$rows["comment_subject"].'</strong><br/>
						<small><em>'.$rows["comment_text"].'</em></small>
					</a>
				</li>
			';
		}
	}
	else
	{
		$output .="
			<li><a href='#' class='text-bold text-italic'>No Notification Found</a></li>
		";
	}
	$output .="<li><a href='all-notification.php' target='_blank' class='btn btn-success btn-xs '>View All Notification</a></li>";
	$query_1 = 'SELECT * FROM comments WHERE comment_status = 0';
	$result_1 = mysqli_query($connect,$query_1);
	$count = mysqli_num_rows($result_1);
	$data = array(
		'notification' => $output,
		'unseen_notification' => $count
	);
	echo json_encode($data);
}