<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Real time notification using jQuery PHP ajax MySql json</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="scripts.js"></script>
</head>
<body>
	<div class="container">
		<h3>Real time notification system using PHP mysql ajax jQuery json</h3>
		<nav class="navbar navbar-default">
		 	<div class="container-fluid">
		    	<div class="navbar-header">
		      		<a class="navbar-brand" href="index.php">Real Time Notification</a>
		    	</div>
		   		<ul class="nav navbar-nav navbar-right">
			      	<li class="dropdown">
			      		<a href="#" class="dropdown-toggle" data-toggle="dropdown">Notification  <span class="label label-danger count"></span></a>
			      		<ul class="dropdown-menu"></ul>
			      	</li>
		    	</ul>
		  	</div>
		</nav>
		<form id='comment_form' method="POST">
			<div class="form-group">
				<label for="subject">Enter Subject</label>
				<input type="text" name="subject" class="form-control" id="subject">
			</div>
			<div class="form-group">
				<label for="comment">Enter Comment</label>
				<textarea rows="5" name="comment" class="form-control" id="comment"></textarea>
			</div>	
			<div class="form-group">
				<input type="submit" name="post" value="Post" class="btn btn-info" id="post">
			</div>
		</form>
	</div>
</body>
</html>