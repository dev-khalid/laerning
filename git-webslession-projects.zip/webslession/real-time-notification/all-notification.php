<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Real time notification using jQuery PHP ajax MySql json</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="scripts.js"></script>
</head>
<body>
	<div class="container">
		<h3>Real time notification system using PHP mysql ajax jQuery json</h3>
		<nav class="navbar navbar-default">
		 	<div class="container-fluid">
		    	<div class="navbar-header">
		      		<a class="navbar-brand" href="index.php">Real Time Notification</a>
		    	</div>
		   		<ul class="nav navbar-nav navbar-right">
			      	<li class="dropdown">
			      		<a href="#" class="dropdown-toggle" data-toggle="dropdown">Notification  <span class="label label-danger count"></span></a>
			      		<ul class="dropdown-menu"></ul>
			      	</li>
		    	</ul>
		  	</div>
		</nav>

		<div class="all-notification">
			<ul>
				<?php
				require_once('config.php');
				$query = "SELECT * FROM comments ORDER BY comment_id DESC";
				$result = mysqli_query($connect,$query);
				if(mysqli_num_rows($result)>0){
					while($rows = mysqli_fetch_array($result)){
				?>
				<li>
					<a href="#">
						<strong><?php echo $rows['comment_subject'];?></strong><br/>
						<small><em><?php echo $rows['comment_text'];?></em></small>
					</a>
				</li>
				<?php
					}
				}
				?>
			</ul>
		</div>
	</div>
</body>
</html>